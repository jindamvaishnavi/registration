package stepdefinition;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class annotation { 
	public static WebDriver driver; 
	@Before
	public void set_up()
	{
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\chromedriver.exe");
		driver =new ChromeDriver();
	}
	@Given("^User is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
	    driver .get("http://localhost:8089/testing/registrationPage.jsp");
	}

	@When("^User enters firstname as \"([^\"]*)\"$")
	public void user_enters_firstname_as(String arg1) throws Throwable {
		Thread.sleep(1000);
		driver.findElement(By.name("first_name")).sendKeys(arg1); 
	}
	@And("^User enters lastname as \"([^\"]*)\"$")
	public void user_enters_lastname_as(String arg1) throws Throwable {
		Thread.sleep(1000);
		driver.findElement(By.name("last_name")).sendKeys(arg1); 
	}

	@And("^User enters email as \"([^\"]*)\"$")
	public void user_enters_email_as(String arg1) throws Throwable {
		Thread.sleep(1000);
		driver.findElement(By.name("Email")).sendKeys(arg1);
	}

	@And("^User enters address as \"([^\"]*)\"$")
	public void user_enters_address_as(String arg1) throws Throwable {
		Thread.sleep(1000);
		driver.findElement(By.name("address")).sendKeys(arg1);
	}

	@And("^User enters city as \"([^\"]*)\"$")
	public void user_enters_city_as(String arg1) throws Throwable {
		Thread.sleep(1000);
		driver.findElement(By.name("city")).sendKeys(arg1);
	}

	@And("^user enters state as \"([^\"]*)\"$")
	public void user_enters_state_as(String arg1) throws Throwable {
		Thread.sleep(1000);
		driver.findElement(By.name("states")).sendKeys(arg1);
	}

	@And("^User enters contactno as \"([^\"]*)\"$")
	public void user_enters_contactno_as(String arg1) throws Throwable {
		Thread.sleep(1000);
		driver.findElement(By.name("contact")).sendKeys(arg1);
	}

	@Then("^User should navigate to project page$")
	public void user_should_navigate_to_project_page() throws Throwable {
		driver .get("http://localhost:8089/testing/project.jsp");
	}

	@When("^User enters project name as \"([^\"]*)\"$")
	public void user_enters_project_name_as(String arg1) throws Throwable {
		Thread.sleep(1000);
		driver.findElement(By.name("project_name")).sendKeys(arg1);
	}

	@And("^User enters client name as \"([^\"]*)\"$")
	public void user_enters_client_name_as(String arg1) throws Throwable {
		Thread.sleep(1000);
		driver.findElement(By.name("client_name")).sendKeys(arg1);
	}

	@And("^User enters team size as \"([^\"]*)\"$")
	public void user_enters_team_size_as(String arg1) throws Throwable {
		Thread.sleep(1000);
		driver.findElement(By.name("team_size")).sendKeys(arg1);
	}

	@Then("^User should navigate to success page$")
	public void user_should_navigate_to_success_page() throws Throwable {
		driver .get("http://localhost:8089/testing/success.jsp");
		Thread.sleep(2000);
		driver.close();
	}
	

} 
